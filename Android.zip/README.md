# Android-Intro-Slider-Screen
Adding Welcome / Intro slider screens in your app is a great way of showcasing the major features of the app. In this article we are going to learn how to add an intro slider to your app where user can swipe through few slides before getting into app.

![Android Intro Slider](http://www.androidhive.info/wp-content/uploads/2016/05/android-welcome-slider-animation-with-dots.gif)
